﻿using System;
namespace EV3Controller
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}
