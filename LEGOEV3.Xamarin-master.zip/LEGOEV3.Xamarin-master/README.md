# LEGOEV3.Xamarin # 

## Create the Xamarin project with Visual Studio with Mac ## 
   > Use Xamarin.iOS and Xamarin.Android
   > I'll try to use Xamarin.Forms next step
## Add iOS support ## 
   > The origin samples hava Android project. I add iOS project.
