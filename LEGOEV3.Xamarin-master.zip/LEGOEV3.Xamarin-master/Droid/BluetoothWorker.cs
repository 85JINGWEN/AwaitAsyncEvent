﻿using System;
using System.Collections.Generic;

namespace EV3Controller.Droid
{
    public class BluetoothWorker
    {
        public BluetoothWorker()
        {
            
        }

        public List<string> GetBluetoothDevicesList(){
            var results = new List<string>();

            return results;
        }
    }
}
